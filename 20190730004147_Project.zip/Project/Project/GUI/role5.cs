﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project.GUI
{
    public partial class role5 : Form
    {
        HiTechdbEntities1 hiTechEntities = new HiTechdbEntities1();

        public role5()
        {
            InitializeComponent();
        }

        private void role5_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = hiTechEntities.Books.ToList();
        }
        private void clearText()
        {
            textID.Text = "";
            textAuthor.Text = "";
            textPrice.Text = "";
            textPublisher.Text = "";
            textYear.Text = "";
            textQOH.Text = "";
            textTitle.Text = "";
        }
        private void textTitle_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            int authorId = Convert.ToInt32(textAuthor.Text);
            int publisherId = Convert.ToInt32(textPublisher.Text);
            int quantity = Convert.ToInt32(textQOH.Text);
            DateTime year = Convert.ToDateTime(textYear.Text);
            double price = Convert.ToDouble(textPrice.Text);
            String title = textTitle.Text;

            Author authCheck = hiTechEntities.Authors.Find(authorId);
            Publisher publishCheck = hiTechEntities.Publishers.Find(publisherId);

            if (authCheck == null || publishCheck == null)
            {
                MessageBox.Show("Couldn't Save Book", "Error");
                clearText();
            }
            else
            {
                Book book = new Book();
                book.PublisherId = publisherId;
                book.QOH = quantity;
                book.UnitPrice = price;
                book.YearPublished = year;
                book.Title = title;
                book.AuthorId = authorId;
                hiTechEntities.Books.Add(book);
                hiTechEntities.SaveChanges();
                MessageBox.Show("Book Saved Successfully");
                clearText();
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            int bookId = Convert.ToInt32(textID.Text);
            Book book = hiTechEntities.Books.Find(bookId);

            if (book == null)
            {
                MessageBox.Show("Couldn't find Book", "Error");
                clearText();
            }
            else
            {
                hiTechEntities.Books.Remove(book);
                hiTechEntities.SaveChanges();
                MessageBox.Show("Book Removed Successfully");
                clearText();
            }
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            int bookId = Convert.ToInt32(textID.Text);
            Book book = hiTechEntities.Books.Find(bookId);

            if (book == null)
            {
                MessageBox.Show("Couldn't find Book", "Error");
                clearText();
            }
            else
            {
                int authorId = Convert.ToInt32(textAuthor.Text);
                int publisherId = Convert.ToInt32(textPublisher.Text);
                int quantity = Convert.ToInt32(textQOH.Text);
                DateTime year = Convert.ToDateTime(textYear.Text);
                double price = Convert.ToDouble(textPrice.Text);
                String title = textTitle.Text;

                book.PublisherId = publisherId;
                book.QOH = quantity;
                book.UnitPrice = price;
                book.YearPublished = year;
                book.Title = title;
                book.AuthorId = authorId;
                hiTechEntities.Books.Add(book);
                hiTechEntities.SaveChanges();
                MessageBox.Show("Book Updated Successfully");
                clearText();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int bookId = Convert.ToInt32(textID.Text);
            Book[] book = new Book[1];
            book[0] = hiTechEntities.Books.Find(bookId);

            if (book == null)
            {
                MessageBox.Show("Couldn't find Book", "Error");
                clearText();
            }
            dataGridView2.DataSource = book.ToList();
        }
    }
}
