﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project.GUI
{
    public partial class role3 : Form
    {
        HiTechdbEntities1 ent = new HiTechdbEntities1();
        public role3()
        {
            InitializeComponent();
        }

        private void role3_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ent.Orders.ToList();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void clearText()
        {
            textCID.Text = "";
            textPaymentMethod.Text = "";
            textPrice.Text = "";
            textStatus.Text = "";
            textOrderType.Text = "";
            textOrderId.Text = "";
        }
        private void buttonSave_Click(object sender, EventArgs e)
        {
            int bookId = Convert.ToInt32(textBookId.Text);
            int customerId = Convert.ToInt32(textCID.Text);
            String quantity = textQuantity.Text;
            String payment = textPaymentMethod.Text;
            double price = Convert.ToDouble(textPrice.Text);
            String status = textStatus.Text;
            String type = textOrderType.Text;

            HiTechdbEntities1 hiTechEntities = new HiTechdbEntities1();
            Book orderCheck = hiTechEntities.Books.Find(bookId);
            Customer custCheck = hiTechEntities.Customers.Find(customerId);

            if (orderCheck == null || custCheck == null)
            {
                MessageBox.Show("Couldn't Save Book", "Error");
                clearText();
            }
            else
            {
                Order order = new Order();
                order.CustomerId = customerId;
                order.BookId = bookId;
                order.PaymentMethod = payment;
                order.OrderType = type;
                order.Status = status;
                order.Price = price;
                order.Quantity = quantity;
                hiTechEntities.Orders.Add(order);
                hiTechEntities.SaveChanges();
                MessageBox.Show("Book Saved");
                clearText();
            }

        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            HiTechdbEntities1 hiTechEntities = new HiTechdbEntities1();
            int orderid = Convert.ToInt32 (textOrderId.Text);
            Order order = hiTechEntities.Orders.Find(orderid);

            if(order == null)
            {
                MessageBox.Show("Couldn't find Book", "Error");
                clearText();
            }
            else
            {
                hiTechEntities.Orders.Remove(order);
                hiTechEntities.SaveChanges();
                MessageBox.Show("Order Removed Successfully");
                clearText();
            }

        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            HiTechdbEntities1 hiTechEntities = new HiTechdbEntities1();
            int bookId = Convert.ToInt32(textBookId.Text);
            int customerId = Convert.ToInt32(textCID.Text);
            String quantity = textQuantity.Text;
            String payment = textPaymentMethod.Text;
            double price = Convert.ToDouble(textPrice.Text);
            String status = textStatus.Text;
            String type = textOrderType.Text;
            int orderid = Convert.ToInt32(textOrderId.Text);
            Order order = hiTechEntities.Orders.Find(orderid);

            if (order == null)
            {
                MessageBox.Show("Couldn't find Book", "Error");
                clearText();
            }
            else
            {
                order.CustomerId = customerId;
                order.BookId = bookId;
                order.PaymentMethod = payment;
                order.OrderType = type;
                order.Status = status;
                order.Price = price;
                order.Quantity = quantity;
                hiTechEntities.SaveChanges();
                MessageBox.Show("Order Updated Successfully");
                clearText();
            }
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            HiTechdbEntities1 hiTechEntities = new HiTechdbEntities1();
            int orderid = Convert.ToInt32(textOrderId.Text);
            Order[] order = new Order[1];
            order[0] = hiTechEntities.Orders.Find(orderid);
            if (order == null)
            {
                MessageBox.Show("Couldn't find Book", "Error");
                clearText();
            }
            else
            {
                dataGridView2.DataSource = order.ToList();
            }
        }
    }
}
