﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project.Data_Access;
using System.Data;

namespace Project.Business
{
    public class Employee
    {
        private int id;
        private string firstName;
        private string lastName;
        private string username;
        private string password;
        private int role;
        public int ID { get => id; set => id = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }
        public int Role { get => role; set => role = value; }

        public bool SaveEmployee(Employee emp)
        {
            return EmployeeDB.SaveBook(emp);
        }
        public DataTable ReadEmployee()
        {
            return EmployeeDB.ReadEmployee();
        }
        public bool UpdateEmployee(Employee emp)
        {
            return EmployeeDB.UpdateRecord(emp);
        }
        public bool DeleteEmployee(Employee emp)
        {
            return EmployeeDB.DeleteRecord(emp);
        }
        public DataTable SearchEmployee(int id)
        {
            return EmployeeDB.SearchRecord(id);
        }
    }
}
