﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project.Data_Access
{
    public class CustomerDB
    {
        DataSet dsClinicDB;
        DataTable dtPatients;
        SqlDataAdapter da;

        public static SqlConnection connDB = UtilityDB.ConnectionDB();
        public static SqlCommand cmd = new SqlCommand();
        public static bool SaveBook(Employee emp)
        {
            bool result = true;
            try
            {
                if (connDB.State == ConnectionState.Closed)
                {
                    connDB = UtilityDB.ConnectionDB();
                    cmd = new SqlCommand();
                }
                cmd.Connection = connDB;
                cmd.CommandText = string.Format("insert into Employee(FirstName,LastName,Username,Password,RoleId) values('{0}','{1}','{2}','{3}',{4})", emp.FirstName, emp.LastName, emp.Username, emp.Password, emp.Role);
                cmd.ExecuteNonQuery();
                connDB.Close();
            }
            catch (Exception)
            {
                result = false;
                throw;
            }
            return result;
        }
        public static DataTable ReadEmployee()
        {
            if (connDB.State == ConnectionState.Closed)
            {
                connDB = UtilityDB.ConnectionDB();
                cmd = new SqlCommand();
            }
            cmd.Connection = connDB;
            cmd.CommandText = "select * from Employee";
            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            reader.Close();
            cmd.Dispose();
            connDB.Close();
            return dt;
        }
        public static bool UpdateRecord(Employee emp)
        {
            bool res = true;
            try
            {
                if (connDB.State == ConnectionState.Closed)
                {
                    connDB = UtilityDB.ConnectionDB();
                    cmd = new SqlCommand();
                }
                cmd.Connection = connDB;
                cmd.CommandText = string.Format("update Employee set FirstName = '{0}',LastName = '{1}',Username = '{2}',Password = '{3}',RoleId ={4} where Id={5}", emp.FirstName, emp.LastName, emp.Username, emp.Password, emp.Role, emp.ID);
                cmd.ExecuteNonQuery();
                connDB.Close();

            }
            catch (Exception)
            {
                res = false;
                throw;
            }
            return res;
        }

        public static DataTable SearchRecord(int empId)
        {
            if (connDB.State == ConnectionState.Closed)
            {
                connDB = UtilityDB.ConnectionDB();
                cmd = new SqlCommand();
            }
            cmd.Connection = connDB;
            cmd.CommandText = "select * from Employee where Id =" + empId;
            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            reader.Close();
            cmd.Dispose();
            connDB.Close();
            return dt;
        }
        public static bool DeleteRecord(Employee emp)
        {
            bool res = true;
            try
            {
                if (connDB.State == ConnectionState.Closed)
                {
                    connDB = UtilityDB.ConnectionDB();
                    cmd = new SqlCommand();
                }
                cmd.Connection = connDB;
                cmd.CommandText = string.Format("Delete Employee where Id={0}", emp.ID);
                cmd.ExecuteNonQuery();
                connDB.Close();

            }
            catch (Exception)
            {
                res = false;
                throw;
            }
            return res;
        }
    }
}
