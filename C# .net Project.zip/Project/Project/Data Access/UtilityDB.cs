﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Project.Data_Access
{
    public static class UtilityDB
    {
        public static SqlConnection ConnectionDB()
        {
            SqlConnection connDB = new SqlConnection("data source = (local)\\SQLSERVER2014 ; database=HiTechdb ; Integrated Security=SSPI");
            connDB.Open();
            return connDB;
        }
    }
}
