﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Project.Business;
using System.Data;

namespace Project.Data_Access
{
    public static class UserDB
    {
        public static SqlConnection connDB = UtilityDB.ConnectionDB();
        public static SqlCommand cmd = new SqlCommand();
        public static int Login(User user)
        {
            if (connDB.State == ConnectionState.Closed)
            {
                connDB = UtilityDB.ConnectionDB();
                cmd = new SqlCommand();
            }
            cmd.Connection = connDB;
            cmd.CommandText = string.Format("select roleid from Employee where Username='{0}' and Password='{1}'", user.Username, user.Password);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            int roleid = 0;
            foreach (DataRow dr in dt.Rows)
            {
                roleid = Convert.ToInt32(dr["roleid"]);
            }
            cmd.Dispose();
            connDB.Close();
            return roleid;
        }
    }
}
