﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Project.Business;

namespace Project.GUI
{
    public partial class role1 : Form
    {
        public role1()
        {
            InitializeComponent();
        }

        private void cleanTextBox()
        {
            textID.Text = string.Empty;
            textFirstName.Text = string.Empty;
            textLastName.Text = string.Empty;
            textUsername.Text = string.Empty;
            textPassword.Text = string.Empty;
            textRole.Text = string.Empty;
        }


        private void role1_Load(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            dataGridView1.DataSource = emp.ReadEmployee();
        }
        
        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (textFirstName.Text == "" || textLastName.Text == "" || textUsername.Text == "" || textPassword.Text == "" || textRole.Text == "")
                MessageBox.Show("Can not be empty!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            Employee emp = new Employee();
            emp.FirstName = textFirstName.Text;
            emp.LastName = textLastName.Text;
            emp.Username = textUsername.Text;
            emp.Password = textPassword.Text;
            emp.Role = Convert.ToInt32(textRole.Text);
            if (emp.SaveEmployee(emp))
                MessageBox.Show("Employee saved ");
            else
                MessageBox.Show("Can not Save!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            cleanTextBox();
        }

       

        private void buttonShow_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            dataGridView1.DataSource = emp.ReadEmployee();
            cleanTextBox();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                textID.Text = row.Cells["ID"].Value.ToString();
                textFirstName.Text = row.Cells["FirstName"].Value.ToString();
                textLastName.Text = row.Cells["LastName"].Value.ToString();
                textUsername.Text = row.Cells["Username"].Value.ToString();
                textPassword.Text = row.Cells["Password"].Value.ToString();
                textRole.Text = row.Cells["RoleId"].Value.ToString();
            }
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            if (textID.Text == "" || textFirstName.Text == "" || textLastName.Text == "" || textUsername.Text == "" || textPassword.Text == "" ||  textRole.Text == "")
            {
                MessageBox.Show("Can not be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Employee emp = new Employee();
                //fill the object with textbox input
                emp.FirstName = textFirstName.Text;
                emp.LastName = textLastName.Text;
                emp.Username = textUsername.Text;
                emp.Password = textPassword.Text;
                emp.Role = Convert.ToInt32(textRole.Text);
                emp.ID = Convert.ToInt32(textID.Text);
                if (emp.UpdateEmployee(emp))
                {
                    MessageBox.Show("Employee Update correctly");
                }
                else
                    MessageBox.Show("Not Update!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cleanTextBox();
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (textID.Text == "")
            {
                MessageBox.Show("Can not be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Employee emp = new Employee();
                //fill the object with textbox input
                emp.ID = Convert.ToInt32(textID.Text);
                if (emp.DeleteEmployee(emp))
                {
                    MessageBox.Show("Employee Deleted correctly");
                }
                else
                    MessageBox.Show("Delete Unsuccessful !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cleanTextBox();
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            if (textID.Text == "")
            {
                MessageBox.Show("Can not be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Employee emp = new Employee();
                emp.ID = Convert.ToInt16(textID.Text);
                var dt = emp.SearchEmployee(emp.ID);
                int rowCount = dt.Rows.Count;
                if (rowCount > 0)
                {
                    dataGridView2.DataSource = dt;
                }
                else
                    MessageBox.Show("Can't find!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textID.Text = "";
            }
        }
    }
}
