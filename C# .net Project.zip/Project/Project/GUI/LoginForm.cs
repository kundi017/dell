﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Project.Business;
using Project.GUI;

namespace Project
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtPass.Text == "" || txtUsername.Text == "")
            {
                MessageBox.Show("Can not be Empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            User user = new User();
            user.Username = txtUsername.Text;
            user.Password = txtPass.Text;
            int roleid = user.Login(user);
            if (roleid == 1)
            {
                role1 mainform = new role1();
                this.Hide();
                mainform.Show();
            }
            else if (roleid == 2)
            {
                role2 mainform = new role2();
                this.Hide();
                mainform.Show();
            }
            else if (roleid == 3)
            {
                role3 mainform = new role3();
                this.Hide();
                mainform.Show();
            }
            else if (roleid == 4)
            {
                role4 mainform = new role4();
                this.Hide();
                mainform.Show();
            }
            else if (roleid == 5)
            {
                role5 mainform = new role5();
                this.Hide();
                mainform.Show();
            }
            else
            {
                MessageBox.Show("Can not login", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtPass_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
