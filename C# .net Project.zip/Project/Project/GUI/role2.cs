﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Project.Data_Access;

namespace Project.GUI
{
    public partial class role2 : Form
    {
        DataSet dsCustomerDB;
        DataTable dtCustomers;
        SqlDataAdapter da;
        public role2()
        {
            InitializeComponent();
        }
        private void clearTextBox()
        {
            textFirstName.Text = string.Empty;
            textLastName.Text = string.Empty;
            textStreet.Text = string.Empty;
            textCity.Text = string.Empty;
            textPC.Text = string.Empty;
            textPhone.Text = string.Empty;
            textFax.Text = string.Empty;
            textCredit.Text = string.Empty;
            textID.Text = string.Empty;
            
        }
        private void role2_Load(object sender, EventArgs e)
        {
            SqlConnection connDB = new SqlConnection("data source = (local)\\SQLSERVER2014 ; database = HiTechdb ; Integrated Security = SSPI");
            dsCustomerDB = new DataSet("CustomerDB");
            dtCustomers = new DataTable("Customer");

            dtCustomers.Columns.Add("ID",typeof(Int32));
            dtCustomers.Columns.Add("FirstName", typeof(string));
            dtCustomers.Columns.Add("LastName", typeof(string));
            dtCustomers.Columns.Add("Street", typeof(string));
            dtCustomers.Columns.Add("City", typeof(string));
            dtCustomers.Columns.Add("PostalCode", typeof(string));
            dtCustomers.Columns.Add("PhoneNumber", typeof(Int64));
            dtCustomers.Columns.Add("FaxNumber", typeof(string));
            dtCustomers.Columns.Add("CreditLimit", typeof(double));
            dtCustomers.PrimaryKey = new DataColumn[] { dtCustomers.Columns["ID"] };
            dsCustomerDB.Tables.Add(dtCustomers);
            da = new SqlDataAdapter("select * from Customer", connDB);
            da.Fill(dsCustomerDB.Tables["Customer"]);
            dataGridView1.DataSource = dtCustomers;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                textFirstName.Text = row.Cells["FirstName"].Value.ToString();
                textLastName.Text = row.Cells["LastName"].Value.ToString();
                textStreet.Text = row.Cells["Street"].Value.ToString();
                textCity.Text = row.Cells["City"].Value.ToString();
                textPC.Text = row.Cells["Postalcode"].Value.ToString();
                textPhone.Text = row.Cells["PhoneNumber"].Value.ToString();
                textFax.Text = row.Cells["FaxNumber"].Value.ToString();
                textCredit.Text = row.Cells["CreditLimit"].Value.ToString();
                textID.Text = row.Cells["ID"].Value.ToString();
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            SqlConnection connDB = new SqlConnection("data source = (local)\\SQLSERVER2014 ; database = HiTechdb ; Integrated Security = SSPI");
            SqlCommand cmd = new SqlCommand("select TOP 1 ID from Customer Order By ID Desc");
            cmd.Connection = connDB;
            connDB.Open();
            int id = Convert.ToInt32(cmd.ExecuteScalar());
            id++;
            string firstName = textFirstName.Text;
            string lastName = textLastName.Text;
            string street = textStreet.Text;
            string city = textCity.Text;
            string postalCode = textPC.Text;
            long phone = Convert.ToInt64(textPhone.Text);
            string fax = textFax.Text;
            double credit = Convert.ToDouble(textCredit.Text);
            dtCustomers.Rows.Add(id,firstName, lastName, street, city, postalCode,phone,fax,credit);
            string xx = string.Format("Insert into Customer(FirstName,LastName,Street,City,PostalCode,PhoneNumber,FaxNumber,CreditLimit) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}')", firstName, lastName,street,city,postalCode,phone,fax,credit);
            da.InsertCommand = new SqlCommand(xx, connDB);
            da.Update(dsCustomerDB, "Customer");
            connDB.Close();
            clearTextBox();
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection connDB = new SqlConnection("data source = (local)\\SQLSERVER2014 ; database = HiTechdb ; Integrated Security = SSPI");
            int id = Convert.ToInt32(textID.Text);
            string firstName = textFirstName.Text;
            string lastName = textLastName.Text;
            string street = textStreet.Text;
            string city = textCity.Text;
            string postalCode = textPC.Text;
            long phone = Convert.ToInt64(textPhone.Text);
            string fax = textFax.Text;
            double credit = Convert.ToDouble(textCredit.Text);
            DataRow drCustomer = dtCustomers.Rows.Find(id);
            drCustomer["FirstName"] = firstName;
            drCustomer["LastName"] = lastName;
            drCustomer["Street"] = street;
            drCustomer["City"] = city;
            drCustomer["PostalCode"] = postalCode;
            drCustomer["PhoneNumber"] = phone;
            drCustomer["FaxNumber"] = fax;
            drCustomer["CreditLimit"] = credit;
            drCustomer["ID"] = id;

            string xx = string.Format("update Customer set FirstName = '{0}' , LastName = '{1}' ,Street = '{2}',City= '{3}',PostalCode= '{4}',PhoneNumber = '{5}',FaxNumber = '{6}',CreditLimit = '{7}' where ID = {8}", firstName, lastName, street, city, postalCode, phone, fax, credit,id);
            da = new SqlDataAdapter();
            da.UpdateCommand = new SqlCommand(xx, connDB);
            da.Update(dsCustomerDB, "Customer");
            connDB.Close();
            clearTextBox();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            SqlConnection connDB = new SqlConnection("data source = (local)\\SQLSERVER2014 ; database = HiTechdb ; Integrated Security = SSPI");
            int id = Convert.ToInt32(textID.Text);
            DataRow drCustomer = dtCustomers.Rows.Find(id);
            drCustomer.Delete();
            string xx = "delete from Customer where ID = " + id;
            da = new SqlDataAdapter();
            da.DeleteCommand = new SqlCommand(xx, connDB);
            da.Update(dsCustomerDB, "Customer");
            connDB.Close();
            clearTextBox();
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            SqlConnection connDB = new SqlConnection("data source = (local)\\SQLSERVER2014 ; database = HiTechdb ; Integrated Security = SSPI");
            int id = Convert.ToInt32(textID.Text);
            DataRow drCustomer = dtCustomers.Rows.Find(id);
            dataGridView2.DataSource = drCustomer;
            connDB.Close();
            clearTextBox();
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            SqlConnection connDB = new SqlConnection("data source = (local)\\SQLSERVER2014 ; database = HiTechdb ; Integrated Security = SSPI");
            da = new SqlDataAdapter("select * from Customer", connDB);
            da.Fill(dsCustomerDB.Tables["Customer"]);
            dataGridView1.DataSource = dtCustomers;
        }
    }
}
