﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project.GUI
{
    public partial class role4 : Form
    {
        public role4()
        {
            InitializeComponent();
        }
        HiTechdbEntities1 hiTechdb = new HiTechdbEntities1();

        private void role4_Load(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            var totals = from order in hiTechdb.Orders
                         group order by order.CustomerId into g
                         select g.Sum(p => p.total);
            int customerId = Convert.ToInt32(txtCustID.Text);

            Customer customer = hiTechdb.Customers.Find(customerId);
            String customerName = customer.FirstName;
            listView1.Items.Clear();
            foreach (var total in totals)
            {

                ListViewItem item = new ListViewItem(Convert.ToString(customerName));
                item.SubItems.Add(Convert.ToString("CAD " + total));
                item.SubItems.Add(Convert.ToString("CAD " + total * 0.15));
                item.SubItems.Add(Convert.ToString("CAD " + (total + total * 0.15)));

                listView1.Items.Add(item);
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
