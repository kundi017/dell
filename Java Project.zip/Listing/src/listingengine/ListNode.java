package listingengine;

public class ListNode<T> {
	public T content;
	public ListNode<T> prev;
	public ListNode<T> next;
	
	public ListNode(T v) {
		content = v;
		prev = null;
		next = null;
	}
}