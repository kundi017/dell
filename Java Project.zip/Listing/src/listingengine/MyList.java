package listingengine;

import java.util.*;

public class MyList<T>   {
	
	// Head will keep first node;
	// Will keep the complete list starting from second node
	public ListNode<T> data, tail;
	
	
	public MyList() {
		data = null;
		tail = null;
	}
	
	public MyList(T v) {
		ListNode<T> temp = new ListNode<T>(v);
		if(data == null) {
			data = temp;
			tail = temp;
		} else {
			tail.next = temp;
		}
	}
	
	public MyList(T[] v) {
		
		//Assign list to the data
		for(T item:v) {
			//System.out.println(v);
			ListNode<T> temp = new ListNode<T>(item);
			if( data == null) {
				data = temp;
			} else {
				tail.next = temp;
			}
			tail = temp;
		}
	}
	
	public boolean isEmpty() {
		// if head list is empty
		return data == null;
	}
	
	public Object[] toArray() {
		ArrayList<T> temp = new ArrayList<T>();
		
		ListNode<T> currentNode = data;
		
		//Check if first node is set
		if(!this.isEmpty()) {
			// Only single node exists
			temp.add(currentNode.content);
			
			while(currentNode.next != null) {
				currentNode = currentNode.next;
				temp.add(currentNode.content);
			}
		} else {
			System.out.println("Warning: List is empty.");
		}
		
		return temp.toArray();
	}
	
	@SuppressWarnings("unchecked")
	public MyList<T> copy() {
		return new MyList<T>((T[]) this.toArray());
	}
	
	public T head() {
		if(data == null) {
			throw new MLInvalidAccessException("", 1);
		}
		return data.content;
	}
	
	public ListNode<T> getFirst() {
		if(data == null) {
			throw new MLInvalidAccessException("Failed to Return First on Empty List.", 50);
		}
		return data;
	}
	
	public ListNode<T> getLast() {
		return tail;
	}
	
	@SuppressWarnings("unchecked")
	public MyList<T> tail() {
		ArrayList<T> temp = new ArrayList<T>();
		
		//Reset List
		ListNode<T> currentNode = data;
		while(currentNode.next != null) {
			currentNode = currentNode.next; 
			temp.add(currentNode.content);
		}
		return new MyList<T>((T[]) temp.toArray());
	}
	
	public T end() {
		if(data == null) {
			throw new MLInvalidAccessException("", 2);
		}
		return tail.content;
	}
	public void append (T e) {
		ListNode<T> temp = new ListNode<T>(e);
		if(data == null) {
			data = temp;
		}
		else {
			tail.next = temp;
		}
		tail = temp;
	}
	
	@SuppressWarnings("unchecked")
	public void concat (MyList<T> lc) {
		// For concatenation, We will be simply appending the data under loop. 
		for(Object item:lc.toArray()) {
			this.append((T) item);
		}
	}
	public MyListIterator<T> iterator() {
		return new MyListIterator<T>(this);
	}
}
