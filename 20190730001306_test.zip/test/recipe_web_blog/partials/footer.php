<footer class="blog-footer">
      <!-- <p>Blog template built for <a href="">Recipe</a> by <a href="">@davejohn</a>.</p> -->
      <p>
        <a href="#">Back to top</a>
		<p> @Kundi, Jagdeep Singh</p>
      </p>
    </footer>

    <!-- Extra scripts here -->
    <script src="js/jquery-3.4.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/5fb6fa5597.js"></script>
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>feather.replace()</script>
  </body>
</html>