<?php 
  include_once '../../includes/bootstrap.php';

  update_user();
  redirect('dashboard/users.php');