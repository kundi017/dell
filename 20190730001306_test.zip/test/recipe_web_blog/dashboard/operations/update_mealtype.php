<?php 
  include_once '../../includes/bootstrap.php';

  update_data('meal_type');
  redirect('dashboard/meal_type.php');