<?php
   include_once 'includes/bootstrap.php';
   logout();
   redirect('index.php');
